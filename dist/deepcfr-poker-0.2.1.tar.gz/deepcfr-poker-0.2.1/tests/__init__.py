"""
Test suite for DeepCFR Poker AI.
"""
# To be done