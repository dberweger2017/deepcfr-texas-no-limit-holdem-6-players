"""
Jupyter notebooks for analysis and exploration.
"""
# To be done